#ifndef HOSPITAL_H_INCLUDED
#define HOSPITAL_H_INCLUDED

int hospital(){

printf(R"EOF(
 | || |___ ____ __(_) |_ __ _| |
 | __ / _ (_-< '_ \ |  _/ _` | |
 |_||_\___/__/ .__/_|\__\__,_|_|
             |_|
)EOF");

}
#endif // HOSPITAL_H_INCLUDED
