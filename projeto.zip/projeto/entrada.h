#ifndef ENTRADA_H_INCLUDED
#define ENTRADA_H_INCLUDED

int entrada(){

int total_frames = 50; // N�mero total de frames da anima��o
    int tempo_espera = 10000; // Tempo de espera entre os frames (em microssegundos)

    // Loop para exibir a anima��o
    for (int i = 0; i <= 100; i++) {
        // Calcula a quantidade de caracteres da barra preenchida
        int num_caracteres = (i * total_frames) / 100;

        // Limpa a linha anterior
        printf("\r");

        // Exibe a barra de preenchimento
        printf("[");
        for (int j = 0; j < num_caracteres; j++) {
            printf("=");
        }
        for (int j = num_caracteres; j < total_frames; j++) {
            printf(" ");
        }
        printf("] %d%%", i);

        // For�a a exibi��o imediata no console
        fflush(stdout);

        // Aguarda o tempo de espera entre os frames
        usleep(tempo_espera);
    }

    printf("\n");


    }


#endif // ENTRADA_H_INCLUDED
