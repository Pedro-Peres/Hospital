#include <stdio.h>
#include <stdlib.h>
#include "hospital.h"
#include "carregar.h"
#include <conio.h>
#include <windows.h>
#include <unistd.h>

#define MAX_USERNAME_LENGTH 50 /// limite de letras
#define MAX_PASSWORD_LENGTH 50 /// limite de letras



void clrscr1()
{
	COORD coordScreen = { 0, 0 };
	DWORD cCharsWritten;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	DWORD dwConSize;
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	GetConsoleScreenBufferInfo(hConsole, &csbi);
	dwConSize = csbi.dwSize.X * csbi.dwSize.Y;
	FillConsoleOutputCharacter(hConsole, TEXT(' '), dwConSize, coordScreen, &cCharsWritten);
	GetConsoleScreenBufferInfo(hConsole, &csbi);
	FillConsoleOutputAttribute(hConsole, csbi.wAttributes, dwConSize, coordScreen, &cCharsWritten);
	SetConsoleCursorPosition(hConsole, coordScreen);
	textcolor(4);  ///cor
    hospital(); /// chamar o header
    textcolor(15); ///cor
	return;
}


void feito(){
textcolor(2); ///cor
printf("Dados carregados com sucesso"); ///frase
textcolor(15); ///cor

}

typedef struct {
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
} User;

void registerUser() {
    User newUser;

    printf("Username: ");
    scanf("%s", newUser.username);

    printf("Password: ");
    scanf("%s", newUser.password);

    // Abre o arquivo para escrita em modo "append" (adiciona no final do arquivo)
    FILE* file = fopen("users.txt", "a");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    // Escreve os dados do novo usu�rio no arquivo
    fprintf(file, "%s %s\n", newUser.username, newUser.password);

    // Fecha o arquivo
    fclose(file);

     textcolor(1);  ///cor
    carregar(); ///barra de 100%
    textcolor(15); ///cor



    feito(); /// carregados com sucesso
}

int loginUser() {
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];

    printf(R"EOF(
 /$$   /$$
| $$  | $$
| $$  | $$  /$$$$$$$  /$$$$$$   /$$$$$$  /$$$$$$$   /$$$$$$  /$$$$$$/$$$$   /$$$$$$
| $$  | $$ /$$_____/ /$$__  $$ /$$__  $$| $$__  $$ |____  $$| $$_  $$_  $$ /$$__  $$
| $$  | $$|  $$$$$$ | $$$$$$$$| $$  \__/| $$  \ $$  /$$$$$$$| $$ \ $$ \ $$| $$$$$$$$
| $$  | $$ \____  $$| $$_____/| $$      | $$  | $$ /$$__  $$| $$ | $$ | $$| $$_____/
|  $$$$$$/ /$$$$$$$/|  $$$$$$$| $$      | $$  | $$|  $$$$$$$| $$ | $$ | $$|  $$$$$$$
 \______/ |_______/  \_______/|__/      |__/  |__/ \_______/|__/ |__/ |__/ \_______/



)EOF");
    scanf("%s", username);

    printf("Password: ");
    scanf("%s", password);

    // Abre o arquivo para leitura
    FILE* file = fopen("users.txt", "r");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 0;
    }

    // L� cada linha do arquivo e compara com o username e password fornecidos
    char fileUsername[MAX_USERNAME_LENGTH];
    char filePassword[MAX_PASSWORD_LENGTH];
    while (fscanf(file, "%s %s", fileUsername, filePassword) != EOF) {
        if (strcmp(username, fileUsername) == 0 && strcmp(password, filePassword) == 0) {
            fclose(file);
            printf("Login bem-sucedido.\n");
            return 1;
        }
    }

    // Fecha o arquivo
    fclose(file);

    printf("Login falhou. Usu�rio ou senha incorretos.\n");
    return 0;
}



int main()
{


    HWND console = GetConsoleWindow(); ///meter em tela cheia
    ShowWindow(console, SW_MAXIMIZE); ///meter em tela cheia


    SMALL_RECT windowSize = {100, 100, 400, 100}; // Definir o tamanho da janela
    COORD bufferSize = {200, 300}; // Definir o tamanho do buffer de tela



    SetConsoleWindowInfo(console, TRUE, &windowSize);
    SetConsoleScreenBufferSize(console, bufferSize);



 textcolor(4);
printf(R"EOF(                        _
                       ,S/  .e.##ee
                     ,SS/_ /#####""
                   ,SSSSSS`|##|
                 ,'|SSSSSS/%##|
                 | ;SSSSS/%%%/ .-""-._                           __..ooo._.sSSSSSSSSS"7.
                 |/SSSSS/%%%/.'       `._ __               _.od888888888888"'  '"SSSSS"
             ___  `"SSS/%%%/"-.,sSSs._   8888o._    __.o888888888""SS""    `-._    `7Sb
      _.sssSSSSSSSSSSS/`%%/ ,sSSSSSSSSS-.888888888888888888888"'.S"         ,SSS""   `7b
   ,+""       ```""SS/%%./,sSSSSSSSS".   `"888888888888888"'.sSS"         ,SS"'        `S.
                    /%%%/sSSSSSSSS"   `s.   `"88888888"'.sSSSS"         ,S"'             7
                   /%%%/ `SSSSSSS$$,..sSS`-.   `"88'.sSSSSSSSS._     ,-'
                  /%%%/    `SSSS$$$$SSS",\\\`-.   `"SSSSSS"  8"""7.-'
                 /`%/      `SS$$$SSS,dP,s.\\//`-.   `SS" ,'`8       ,ee888888ee.
        ,oo8888oo/ /         `"""",d88Pd8888./,-'/`.  `,-._`d'    ,d88888888888888b.
     ,d888888888/ /8b.          d8888Pd8888888bd88b`.  :_._`8   ,888888"'    '""88888.
   ,888P'      / /"888b.       d88888`8888888Pd8888 :  :_`-.( ,d8888.__           7888b.
  d88P        / /   `788b     (88888:. `8888Pd88888 ;  ; `-._ 8888P_Z_.>-""--.._   `8888
 d88'     ,--/ /      `88b     `88888b`. `8P 78888";  ;      `"*88_,"   s88s.       `888b
d88'    ,',$/ /$$$$.   `88b      `8888b `. `"'88"_/_,'`-._         `-.d8"88"8P.      `888.
888    ; ,$$$$$$$$$'    888        `"8'   `---------------`-.._      8888888888       888'
888    : `$$$$$$$':     888                                 '888b`-._8s888888"P      .888'
788.   `  `$$$$'  ;     88P                                  8888.   "8878888P'      d888
 88b    `.  `"' ,'     d88'                                  '888b     '88s8"'     .d888'
 `88b.    `-..-'      d88'                                    '888b.             .dd888'
   788b.            ,888'                                       7888b._       _.d8888P
    `7888oo..__..oo888'                                          `"8888888888888888"'
      `"7888888888P"'                                               `"788 Peres DT"'  )EOF");

      printf("\n\n\n\n");
      entrada();
      clrscr1();


    int escolha;  ///variaveis

    textcolor(15);  ///cor

    Sleep(5000); /// Tempo para aparecer
    textcolor(2); ///cor
    printf(R"EOF(
   /$$         /$$                           /$$
 /$$$$        | $$                          |__/
|_  $$        | $$        /$$$$$$   /$$$$$$  /$$ /$$$$$$$
  | $$ /$$$$$$| $$       /$$__  $$ /$$__  $$| $$| $$__  $$
  | $$|______/| $$      | $$  \ $$| $$  \ $$| $$| $$  \ $$
  | $$        | $$      | $$  | $$| $$  | $$| $$| $$  | $$
 /$$$$$$      | $$$$$$$$|  $$$$$$/|  $$$$$$$| $$| $$  | $$
|______/      |________/ \______/  \____  $$|__/|__/  |__/
                                   /$$  \ $$
                                  |  $$$$$$/
                                   \______/
)EOF"); ///op��o
    Sleep(500); /// Tempo para aparecer
    textcolor(6); ///cor
    printf(R"EOF(
  /$$$$$$         /$$$$$$$                      /$$             /$$
 /$$__  $$       | $$__  $$                    |__/            | $$
|__/  \ $$       | $$  \ $$  /$$$$$$   /$$$$$$  /$$  /$$$$$$$ /$$$$$$    /$$$$$$   /$$$$$$
  /$$$$$$//$$$$$$| $$$$$$$/ /$$__  $$ /$$__  $$| $$ /$$_____/|_  $$_/   /$$__  $$ /$$__  $$
 /$$____/|______/| $$__  $$| $$$$$$$$| $$  \ $$| $$|  $$$$$$   | $$    | $$  \__/| $$  \ $$
| $$             | $$  \ $$| $$_____/| $$  | $$| $$ \____  $$  | $$ /$$| $$      | $$  | $$
| $$$$$$$$       | $$  | $$|  $$$$$$$|  $$$$$$$| $$ /$$$$$$$/  |  $$$$/| $$      |  $$$$$$/
|________/       |__/  |__/ \_______/ \____  $$|__/|_______/    \___/  |__/       \______/
                                      /$$  \ $$
                                     |  $$$$$$/
                                      \______/
)EOF"); ///op��o
    Sleep(500); /// Tempo para aparecer
    textcolor(5); ///cor
    printf(R"EOF(
  /$$$$$$           /$$$$$$                                /$$
 /$$__  $$         /$$__  $$                              |__/
|__/  \ $$        | $$  \ $$ /$$$$$$$   /$$$$$$  /$$$$$$$  /$$ /$$$$$$/$$$$   /$$$$$$
   /$$$$$/ /$$$$$$| $$$$$$$$| $$__  $$ /$$__  $$| $$__  $$| $$| $$_  $$_  $$ /$$__  $$
  |___  $$|______/| $$__  $$| $$  \ $$| $$  \ $$| $$  \ $$| $$| $$ \ $$ \ $$| $$  \ $$
 /$$  \ $$        | $$  | $$| $$  | $$| $$  | $$| $$  | $$| $$| $$ | $$ | $$| $$  | $$
|  $$$$$$/        | $$  | $$| $$  | $$|  $$$$$$/| $$  | $$| $$| $$ | $$ | $$|  $$$$$$/
 \______/         |__/  |__/|__/  |__/ \______/ |__/  |__/|__/|__/ |__/ |__/ \______/



)EOF");///op��o


Sleep(500); /// Tempo para aparecer
    textcolor(8); ///cor

    printf(R"EOF(
 /$$   /$$         /$$$$$$$$           /$$   /$$
| $$  | $$        | $$_____/          |__/  | $$
| $$  | $$        | $$       /$$   /$$ /$$ /$$$$$$
| $$$$$$$$ /$$$$$$| $$$$$   |  $$ /$$/| $$|_  $$_/
|_____  $$|______/| $$__/    \  $$$$/ | $$  | $$
      | $$        | $$        >$$  $$ | $$  | $$ /$$
      | $$        | $$$$$$$$ /$$/\  $$| $$  |  $$$$/
      |__/        |________/|__/  \__/|__/   \___/



)EOF");





    ///Escolha de op��o para pessoa escolher

    printf("Opcao-->");
    scanf("%i",&escolha); ///recolher a op��o que pretendeu






    switch(escolha) {

    case 1:
    if (loginUser()) {








                    return 0;
                }

      break;

      case 2:
        registerUser();
      break;

      case 3:

      break;

      case 4:

      break;}









    return 0;
}
